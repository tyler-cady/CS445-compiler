/* A Bison parser, made by GNU Bison 2.3.  */

/* Skeleton implementation for Bison's Yacc-like parsers in C

   Copyright (C) 1984, 1989, 1990, 2000, 2001, 2002, 2003, 2004, 2005, 2006
   Free Software Foundation, Inc.

   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2, or (at your option)
   any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin Street, Fifth Floor,
   Boston, MA 02110-1301, USA.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* C LALR(1) parser skeleton written by Richard Stallman, by
   simplifying the original so-called "semantic" parser.  */

/* All symbols defined below should begin with yy or YY, to avoid
   infringing on user name space.  This should be done even for local
   variables, as they might otherwise be expanded by user macros.
   There are some unavoidable exceptions within include files to
   define necessary library symbols; they are noted "INFRINGES ON
   USER NAME SPACE" below.  */

/* Identify Bison output.  */
#define YYBISON 1

/* Bison version.  */
#define YYBISON_VERSION "2.3"

/* Skeleton name.  */
#define YYSKELETON_NAME "yacc.c"

/* Pure parsers.  */
#define YYPURE 0

/* Using locations.  */
#define YYLSP_NEEDED 0



/* Tokens.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
   /* Put the tokens into the symbol table, so that GDB and other debuggers
      know about them.  */
   enum yytokentype {
     PLUS = 258,
     MINUS = 259,
     OR = 260,
     EQ = 261,
     NE = 262,
     LT = 263,
     GT = 264,
     LE = 265,
     GE = 266,
     STAR = 267,
     SLASH = 268,
     DIV = 269,
     MOD = 270,
     AND = 271,
     NOT = 272,
     COMMA = 273,
     P = 274,
     B = 275,
     SEMICOLON = 276,
     COLON = 277,
     RARRAY = 278,
     IARRAY = 279,
     BEGINKW = 280,
     END = 281,
     IF = 282,
     WHILE = 283,
     FOR = 284,
     REPEAT = 285,
     THEN = 286,
     ELSE = 287,
     UNTIL = 288,
     DO = 289,
     DECL = 290,
     INUM = 291,
     RNUM = 292,
     ID = 293,
     RELOP = 294,
     ADDOP = 295,
     MULOP = 296,
     ANDOP = 297,
     OROP = 298,
     ASSIGNOP = 299,
     DOUBLEDOT = 300,
     VAR = 301,
     INTEGER = 302,
     REAL = 303,
     ARRAY = 304,
     OF = 305,
     PROGRAM = 306,
     FUNCTION = 307,
     PROCEDURE = 308,
     ELSEFIX = 309
   };
#endif
/* Tokens.  */
#define PLUS 258
#define MINUS 259
#define OR 260
#define EQ 261
#define NE 262
#define LT 263
#define GT 264
#define LE 265
#define GE 266
#define STAR 267
#define SLASH 268
#define DIV 269
#define MOD 270
#define AND 271
#define NOT 272
#define COMMA 273
#define P 274
#define B 275
#define SEMICOLON 276
#define COLON 277
#define RARRAY 278
#define IARRAY 279
#define BEGINKW 280
#define END 281
#define IF 282
#define WHILE 283
#define FOR 284
#define REPEAT 285
#define THEN 286
#define ELSE 287
#define UNTIL 288
#define DO 289
#define DECL 290
#define INUM 291
#define RNUM 292
#define ID 293
#define RELOP 294
#define ADDOP 295
#define MULOP 296
#define ANDOP 297
#define OROP 298
#define ASSIGNOP 299
#define DOUBLEDOT 300
#define VAR 301
#define INTEGER 302
#define REAL 303
#define ARRAY 304
#define OF 305
#define PROGRAM 306
#define FUNCTION 307
#define PROCEDURE 308
#define ELSEFIX 309




/* Copy the first part of user declarations.  */
#line 1 "src/pc.y"

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>

#include <string.h>
#include "ptype.h"
#include "util.h"
#include "error.h"
#include "list.h"
#include "tree.h"
#include "hash.h"

#define MAX_ERRORS 20

extern int yylex();       /* Declare yylex() */
extern int yylineno;
extern FILE *yyin;
char *yyfilename;
// void yyerror(const char *s); /* Declare yyerror() */
int error_count = 0;
tree_t *tree;
hash_t *symbol_tbl;


/* Enabling traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif

/* Enabling verbose error messages.  */
#ifdef YYERROR_VERBOSE
# undef YYERROR_VERBOSE
# define YYERROR_VERBOSE 1
#else
# define YYERROR_VERBOSE 0
#endif

/* Enabling the token table.  */
#ifndef YYTOKEN_TABLE
# define YYTOKEN_TABLE 0
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
typedef union YYSTYPE
#line 27 "src/pc.y"
{
    int ival;
    float rval;
    int opval;
    char *sval;
    tree_t *tval;       /* tree value */
    ptype_t *type_val; /* type value */
    ltype_t *ltype_val; /* list of types */
    lname_t *lname_val; /* list of names */
}
/* Line 193 of yacc.c.  */
#line 240 "pc.tab.c"
	YYSTYPE;
# define yystype YYSTYPE /* obsolescent; will be withdrawn */
# define YYSTYPE_IS_DECLARED 1
# define YYSTYPE_IS_TRIVIAL 1
#endif



/* Copy the second part of user declarations.  */


/* Line 216 of yacc.c.  */
#line 253 "pc.tab.c"

#ifdef short
# undef short
#endif

#ifdef YYTYPE_UINT8
typedef YYTYPE_UINT8 yytype_uint8;
#else
typedef unsigned char yytype_uint8;
#endif

#ifdef YYTYPE_INT8
typedef YYTYPE_INT8 yytype_int8;
#elif (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
typedef signed char yytype_int8;
#else
typedef short int yytype_int8;
#endif

#ifdef YYTYPE_UINT16
typedef YYTYPE_UINT16 yytype_uint16;
#else
typedef unsigned short int yytype_uint16;
#endif

#ifdef YYTYPE_INT16
typedef YYTYPE_INT16 yytype_int16;
#else
typedef short int yytype_int16;
#endif

#ifndef YYSIZE_T
# ifdef __SIZE_TYPE__
#  define YYSIZE_T __SIZE_TYPE__
# elif defined size_t
#  define YYSIZE_T size_t
# elif ! defined YYSIZE_T && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#  include <stddef.h> /* INFRINGES ON USER NAME SPACE */
#  define YYSIZE_T size_t
# else
#  define YYSIZE_T unsigned int
# endif
#endif

#define YYSIZE_MAXIMUM ((YYSIZE_T) -1)

#ifndef YY_
# if defined YYENABLE_NLS && YYENABLE_NLS
#  if ENABLE_NLS
#   include <libintl.h> /* INFRINGES ON USER NAME SPACE */
#   define YY_(msgid) dgettext ("bison-runtime", msgid)
#  endif
# endif
# ifndef YY_
#  define YY_(msgid) msgid
# endif
#endif

/* Suppress unused-variable warnings by "using" E.  */
#if ! defined lint || defined __GNUC__
# define YYUSE(e) ((void) (e))
#else
# define YYUSE(e) /* empty */
#endif

/* Identity function, used to suppress warnings about constant conditions.  */
#ifndef lint
# define YYID(n) (n)
#else
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static int
YYID (int i)
#else
static int
YYID (i)
    int i;
#endif
{
  return i;
}
#endif

#if ! defined yyoverflow || YYERROR_VERBOSE

/* The parser invokes alloca or malloc; define the necessary symbols.  */

# ifdef YYSTACK_USE_ALLOCA
#  if YYSTACK_USE_ALLOCA
#   ifdef __GNUC__
#    define YYSTACK_ALLOC __builtin_alloca
#   elif defined __BUILTIN_VA_ARG_INCR
#    include <alloca.h> /* INFRINGES ON USER NAME SPACE */
#   elif defined _AIX
#    define YYSTACK_ALLOC __alloca
#   elif defined _MSC_VER
#    include <malloc.h> /* INFRINGES ON USER NAME SPACE */
#    define alloca _alloca
#   else
#    define YYSTACK_ALLOC alloca
#    if ! defined _ALLOCA_H && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
#     include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#     ifndef _STDLIB_H
#      define _STDLIB_H 1
#     endif
#    endif
#   endif
#  endif
# endif

# ifdef YYSTACK_ALLOC
   /* Pacify GCC's `empty if-body' warning.  */
#  define YYSTACK_FREE(Ptr) do { /* empty */; } while (YYID (0))
#  ifndef YYSTACK_ALLOC_MAXIMUM
    /* The OS might guarantee only one guard page at the bottom of the stack,
       and a page size can be as small as 4096 bytes.  So we cannot safely
       invoke alloca (N) if N exceeds 4096.  Use a slightly smaller number
       to allow for a few compiler-allocated temporary stack slots.  */
#   define YYSTACK_ALLOC_MAXIMUM 4032 /* reasonable circa 2006 */
#  endif
# else
#  define YYSTACK_ALLOC YYMALLOC
#  define YYSTACK_FREE YYFREE
#  ifndef YYSTACK_ALLOC_MAXIMUM
#   define YYSTACK_ALLOC_MAXIMUM YYSIZE_MAXIMUM
#  endif
#  if (defined __cplusplus && ! defined _STDLIB_H \
       && ! ((defined YYMALLOC || defined malloc) \
	     && (defined YYFREE || defined free)))
#   include <stdlib.h> /* INFRINGES ON USER NAME SPACE */
#   ifndef _STDLIB_H
#    define _STDLIB_H 1
#   endif
#  endif
#  ifndef YYMALLOC
#   define YYMALLOC malloc
#   if ! defined malloc && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void *malloc (YYSIZE_T); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
#  ifndef YYFREE
#   define YYFREE free
#   if ! defined free && ! defined _STDLIB_H && (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
void free (void *); /* INFRINGES ON USER NAME SPACE */
#   endif
#  endif
# endif
#endif /* ! defined yyoverflow || YYERROR_VERBOSE */


#if (! defined yyoverflow \
     && (! defined __cplusplus \
	 || (defined YYSTYPE_IS_TRIVIAL && YYSTYPE_IS_TRIVIAL)))

/* A type that is properly aligned for any stack member.  */
union yyalloc
{
  yytype_int16 yyss;
  YYSTYPE yyvs;
  };

/* The size of the maximum gap between one aligned stack and the next.  */
# define YYSTACK_GAP_MAXIMUM (sizeof (union yyalloc) - 1)

/* The size of an array large to enough to hold all stacks, each with
   N elements.  */
# define YYSTACK_BYTES(N) \
     ((N) * (sizeof (yytype_int16) + sizeof (YYSTYPE)) \
      + YYSTACK_GAP_MAXIMUM)

/* Copy COUNT objects from FROM to TO.  The source and destination do
   not overlap.  */
# ifndef YYCOPY
#  if defined __GNUC__ && 1 < __GNUC__
#   define YYCOPY(To, From, Count) \
      __builtin_memcpy (To, From, (Count) * sizeof (*(From)))
#  else
#   define YYCOPY(To, From, Count)		\
      do					\
	{					\
	  YYSIZE_T yyi;				\
	  for (yyi = 0; yyi < (Count); yyi++)	\
	    (To)[yyi] = (From)[yyi];		\
	}					\
      while (YYID (0))
#  endif
# endif

/* Relocate STACK from its old location to the new one.  The
   local variables YYSIZE and YYSTACKSIZE give the old and new number of
   elements in the stack, and YYPTR gives the new location of the
   stack.  Advance YYPTR to a properly aligned location for the next
   stack.  */
# define YYSTACK_RELOCATE(Stack)					\
    do									\
      {									\
	YYSIZE_T yynewbytes;						\
	YYCOPY (&yyptr->Stack, Stack, yysize);				\
	Stack = &yyptr->Stack;						\
	yynewbytes = yystacksize * sizeof (*Stack) + YYSTACK_GAP_MAXIMUM; \
	yyptr += yynewbytes / sizeof (*yyptr);				\
      }									\
    while (YYID (0))

#endif

/* YYFINAL -- State number of the termination state.  */
#define YYFINAL  6
/* YYLAST -- Last index in YYTABLE.  */
#define YYLAST   192

/* YYNTOKENS -- Number of terminals.  */
#define YYNTOKENS  63
/* YYNNTS -- Number of nonterminals.  */
#define YYNNTS  21
/* YYNRULES -- Number of rules.  */
#define YYNRULES  56
/* YYNRULES -- Number of states.  */
#define YYNSTATES  142

/* YYTRANSLATE(YYLEX) -- Bison symbol number corresponding to YYLEX.  */
#define YYUNDEFTOK  2
#define YYMAXUTOK   309

#define YYTRANSLATE(YYX)						\
  ((unsigned int) (YYX) <= YYMAXUTOK ? yytranslate[YYX] : YYUNDEFTOK)

/* YYTRANSLATE[YYLEX] -- Bison symbol number corresponding to YYLEX.  */
static const yytype_uint8 yytranslate[] =
{
       0,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
      55,    56,     2,     2,    59,     2,    58,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,    60,    57,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,    61,     2,    62,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     2,     2,     2,     2,
       2,     2,     2,     2,     2,     2,     1,     2,     3,     4,
       5,     6,     7,     8,     9,    10,    11,    12,    13,    14,
      15,    16,    17,    18,    19,    20,    21,    22,    23,    24,
      25,    26,    27,    28,    29,    30,    31,    32,    33,    34,
      35,    36,    37,    38,    39,    40,    41,    42,    43,    44,
      45,    46,    47,    48,    49,    50,    51,    52,    53,    54
};

#if YYDEBUG
/* YYPRHS[YYN] -- Index of the first RHS symbol of rule number YYN in
   YYRHS.  */
static const yytype_uint8 yyprhs[] =
{
       0,     0,     3,     5,    16,    18,    22,    24,    31,    32,
      41,    50,    59,    68,    70,    76,    82,    84,    86,    90,
      91,    96,   103,   108,   112,   113,   117,   123,   127,   129,
     130,   134,   136,   140,   142,   144,   151,   156,   161,   166,
     174,   179,   181,   186,   188,   192,   194,   198,   202,   205,
     209,   213,   217,   221,   223,   225,   227
};

/* YYRHS -- A `-1'-separated list of the rules' RHS.  */
static const yytype_int8 yyrhs[] =
{
      64,     0,    -1,    65,    -1,    51,    38,    55,    66,    56,
      57,    67,    71,    76,    58,    -1,     1,    -1,    66,    59,
      38,    -1,    38,    -1,    67,    46,    66,    60,    68,    57,
      -1,    -1,    49,    61,    36,    45,    36,    62,    50,    47,
      -1,    49,    61,    36,    45,    36,    62,    50,    48,    -1,
      49,    61,    83,    45,    83,    62,    50,    47,    -1,    49,
      61,    83,    45,    83,    62,    50,    48,    -1,    70,    -1,
      61,    83,    45,    83,    62,    -1,    61,    36,    45,    36,
      62,    -1,    47,    -1,    48,    -1,    71,    72,    57,    -1,
      -1,    73,    67,    71,    76,    -1,    52,    38,    74,    60,
      70,    57,    -1,    53,    38,    74,    57,    -1,    55,    75,
      56,    -1,    -1,    66,    60,    68,    -1,    75,    57,    66,
      60,    68,    -1,    25,    77,    26,    -1,    78,    -1,    -1,
      78,    57,    79,    -1,    79,    -1,    80,    44,    83,    -1,
      81,    -1,    76,    -1,    27,    83,    31,    79,    32,    79,
      -1,    27,    83,    31,    79,    -1,    28,    83,    34,    79,
      -1,    30,    79,    33,    83,    -1,    29,    38,    44,    83,
      69,    34,    79,    -1,    38,    61,    83,    62,    -1,    38,
      -1,    38,    55,    82,    56,    -1,    38,    -1,    82,    59,
      83,    -1,    83,    -1,    83,     5,    83,    -1,    83,    16,
      83,    -1,    17,    83,    -1,    83,    39,    83,    -1,    83,
      40,    83,    -1,    83,    41,    83,    -1,    55,    83,    56,
      -1,    36,    -1,    37,    -1,    80,    -1,    38,    55,    82,
      56,    -1
};

/* YYRLINE[YYN] -- source line where rule number YYN was defined.  */
static const yytype_uint16 yyrline[] =
{
       0,   111,   111,   114,   116,   120,   127,   137,   150,   153,
     157,   161,   165,   169,   172,   176,   182,   189,   199,   200,
     204,   208,   209,   213,   214,   218,   219,   223,   227,   228,
     232,   233,   237,   238,   239,   240,   241,   242,   243,   244,
     248,   250,   254,   255,   259,   260,   263,   264,   265,   266,
     267,   268,   269,   270,   271,   272,   273
};
#endif

#if YYDEBUG || YYERROR_VERBOSE || YYTOKEN_TABLE
/* YYTNAME[SYMBOL-NUM] -- String name of the symbol SYMBOL-NUM.
   First, the terminals, then, starting at YYNTOKENS, nonterminals.  */
static const char *const yytname[] =
{
  "$end", "error", "$undefined", "PLUS", "MINUS", "OR", "EQ", "NE", "LT",
  "GT", "LE", "GE", "STAR", "SLASH", "DIV", "MOD", "AND", "NOT", "COMMA",
  "P", "B", "SEMICOLON", "COLON", "RARRAY", "IARRAY", "BEGINKW", "END",
  "IF", "WHILE", "FOR", "REPEAT", "THEN", "ELSE", "UNTIL", "DO", "DECL",
  "INUM", "RNUM", "ID", "RELOP", "ADDOP", "MULOP", "ANDOP", "OROP",
  "ASSIGNOP", "DOUBLEDOT", "VAR", "INTEGER", "REAL", "ARRAY", "OF",
  "PROGRAM", "FUNCTION", "PROCEDURE", "ELSEFIX", "'('", "')'", "';'",
  "'.'", "','", "':'", "'['", "']'", "$accept", "start", "program",
  "identifier_list", "declarations", "type", "range", "standard_type",
  "subprogram_declarations", "subprogram_declaration", "subprogram_header",
  "arguments", "parameter_list", "compound_statement",
  "optional_statements", "statement_list", "statement", "variable",
  "procedure_statement", "expression_list", "expression", 0
};
#endif

# ifdef YYPRINT
/* YYTOKNUM[YYLEX-NUM] -- Internal token number corresponding to
   token YYLEX-NUM.  */
static const yytype_uint16 yytoknum[] =
{
       0,   256,   257,   258,   259,   260,   261,   262,   263,   264,
     265,   266,   267,   268,   269,   270,   271,   272,   273,   274,
     275,   276,   277,   278,   279,   280,   281,   282,   283,   284,
     285,   286,   287,   288,   289,   290,   291,   292,   293,   294,
     295,   296,   297,   298,   299,   300,   301,   302,   303,   304,
     305,   306,   307,   308,   309,    40,    41,    59,    46,    44,
      58,    91,    93
};
# endif

/* YYR1[YYN] -- Symbol number of symbol that rule YYN derives.  */
static const yytype_uint8 yyr1[] =
{
       0,    63,    64,    65,    65,    66,    66,    67,    67,    68,
      68,    68,    68,    68,    69,    69,    70,    70,    71,    71,
      72,    73,    73,    74,    74,    75,    75,    76,    77,    77,
      78,    78,    79,    79,    79,    79,    79,    79,    79,    79,
      80,    80,    81,    81,    82,    82,    83,    83,    83,    83,
      83,    83,    83,    83,    83,    83,    83
};

/* YYR2[YYN] -- Number of symbols composing right hand side of rule YYN.  */
static const yytype_uint8 yyr2[] =
{
       0,     2,     1,    10,     1,     3,     1,     6,     0,     8,
       8,     8,     8,     1,     5,     5,     1,     1,     3,     0,
       4,     6,     4,     3,     0,     3,     5,     3,     1,     0,
       3,     1,     3,     1,     1,     6,     4,     4,     4,     7,
       4,     1,     4,     1,     3,     1,     3,     3,     2,     3,
       3,     3,     3,     1,     1,     1,     4
};

/* YYDEFACT[STATE-NAME] -- Default rule to reduce with in state
   STATE-NUM when YYTABLE doesn't specify something else to do.  Zero
   means the default is an error.  */
static const yytype_uint8 yydefact[] =
{
       0,     4,     0,     0,     2,     0,     1,     0,     6,     0,
       0,     0,     8,     5,    19,     0,     0,     0,    29,     0,
       0,     0,     8,     0,     0,     0,     0,     0,     0,    43,
      34,     0,    28,    31,     0,    33,    24,    24,    18,    19,
       3,    16,    17,     0,     0,    13,     0,    53,    54,    41,
       0,    55,     0,     0,     0,     0,     0,     0,    27,     0,
       0,     0,     0,     0,     0,     0,     7,    48,     0,     0,
       0,     0,     0,     0,     0,     0,     0,     0,     0,     0,
      45,     0,    30,    32,     0,     0,     0,    22,    20,    53,
       0,     0,    52,    46,    47,    36,    49,    50,    51,    37,
       0,    38,    42,     0,    40,     0,    23,     0,     0,     0,
       0,    56,     0,     0,     0,    44,    25,     0,    21,     0,
       0,    35,    53,     0,     0,     0,     0,     0,     0,     0,
      39,    26,     0,     0,     0,     0,     9,    10,    11,    12,
      15,    14
};

/* YYDEFGOTO[NTERM-NUM].  */
static const yytype_int8 yydefgoto[] =
{
      -1,     3,     4,     9,    14,    44,   114,    45,    16,    21,
      22,    62,    85,    30,    31,    32,    33,    51,    35,    79,
      80
};

/* YYPACT[STATE-NUM] -- Index in YYTABLE of the portion describing
   STATE-NUM.  */
#define YYPACT_NINF -100
static const yytype_int16 yypact[] =
{
       6,  -100,   -27,    13,  -100,   -21,  -100,    -9,  -100,   -38,
     -40,    -1,  -100,  -100,    -4,    -9,   -13,   -28,    42,    28,
      35,    18,  -100,    19,   111,    98,    98,    45,    42,   -39,
    -100,    61,    33,  -100,    48,  -100,    56,    56,  -100,    -4,
    -100,  -100,  -100,    65,    71,  -100,    98,  -100,  -100,   -46,
      98,  -100,   133,   116,    87,    84,    98,    98,  -100,    42,
      98,    -9,    77,    76,   -13,   106,  -100,     3,    98,    73,
      98,    98,    42,    98,    98,    98,    42,    98,    98,   -36,
     146,    20,  -100,   146,   -15,     7,    49,  -100,  -100,   109,
      79,   -29,  -100,   146,   146,   120,     3,     3,     3,  -100,
      69,   146,  -100,    98,  -100,   111,  -100,    -9,   118,   127,
      98,  -100,    42,   110,   142,   146,  -100,   107,  -100,   115,
      60,  -100,   134,   100,    42,   111,   128,   130,   145,    98,
    -100,  -100,   121,   123,   122,    63,  -100,  -100,  -100,  -100,
    -100,  -100
};

/* YYPGOTO[NTERM-NUM].  */
static const yytype_int16 yypgoto[] =
{
    -100,  -100,  -100,   -14,   160,   -99,  -100,    97,   149,  -100,
    -100,   152,  -100,    -2,  -100,  -100,   -26,   -18,  -100,   124,
     -22
};

/* YYTABLE[YYPACT[STATE-NUM]].  What to do in state STATE-NUM.  If
   positive, shift that token.  If negative, reduce the rule which
   number is the opposite.  If zero, do what YYDEFACT says.
   If YYTABLE_NINF, syntax error.  */
#define YYTABLE_NINF -42
static const yytype_int16 yytable[] =
{
      34,    17,    55,    52,    53,   -41,   116,     1,    70,    68,
      34,     5,    18,     6,    23,    57,    56,    12,    10,    71,
     102,    11,    57,   103,    67,    70,   131,   111,    69,     8,
     103,    11,    24,    82,     7,    81,    71,    13,    83,    19,
      20,    34,    15,    90,    11,   105,    95,    84,    93,    94,
      99,    96,    97,    98,    34,   100,   101,     2,    34,    73,
      74,    75,    88,   106,   107,    70,    36,    18,    70,    25,
      26,    27,    28,    37,    70,    38,    71,    40,    70,    71,
      29,   115,   104,    54,    70,    71,   121,    58,   120,    71,
      59,   123,    60,   117,    34,    71,    41,    42,   130,    73,
      74,    75,    73,    74,    75,    70,    34,   135,    73,    74,
      75,    61,    73,    74,    75,    46,    71,    78,    73,    74,
      75,    70,   127,    46,   110,   141,    65,    46,    66,    92,
     113,    77,    71,    87,    47,    48,    49,    86,    70,    73,
      74,    75,    89,    48,    49,   129,   122,    48,    49,    71,
      76,    70,   112,    50,   109,    73,    74,    75,    41,    42,
      43,    50,    71,   119,    72,    50,    11,   125,   136,   137,
     138,   139,    73,    74,    75,   118,   124,   126,   132,   128,
     133,   134,    39,   108,   140,    73,    74,    75,    64,    63,
       0,     0,    91
};

static const yytype_int16 yycheck[] =
{
      18,    15,    28,    25,    26,    44,   105,     1,     5,    55,
      28,    38,    25,     0,    16,    61,    55,    57,    56,    16,
      56,    59,    61,    59,    46,     5,   125,    56,    50,    38,
      59,    59,    60,    59,    55,    57,    16,    38,    60,    52,
      53,    59,    46,    65,    59,    60,    72,    61,    70,    71,
      76,    73,    74,    75,    72,    77,    78,    51,    76,    39,
      40,    41,    64,    56,    57,     5,    38,    25,     5,    27,
      28,    29,    30,    38,     5,    57,    16,    58,     5,    16,
      38,   103,    62,    38,     5,    16,   112,    26,   110,    16,
      57,   113,    44,   107,   112,    16,    47,    48,   124,    39,
      40,    41,    39,    40,    41,     5,   124,   129,    39,    40,
      41,    55,    39,    40,    41,    17,    16,    33,    39,    40,
      41,     5,    62,    17,    45,    62,    61,    17,    57,    56,
      61,    44,    16,    57,    36,    37,    38,    60,     5,    39,
      40,    41,    36,    37,    38,    45,    36,    37,    38,    16,
      34,     5,    32,    55,    45,    39,    40,    41,    47,    48,
      49,    55,    16,    36,    31,    55,    59,    60,    47,    48,
      47,    48,    39,    40,    41,    57,    34,    62,    50,    45,
      50,    36,    22,    86,    62,    39,    40,    41,    39,    37,
      -1,    -1,    68
};

/* YYSTOS[STATE-NUM] -- The (internal number of the) accessing
   symbol of state STATE-NUM.  */
static const yytype_uint8 yystos[] =
{
       0,     1,    51,    64,    65,    38,     0,    55,    38,    66,
      56,    59,    57,    38,    67,    46,    71,    66,    25,    52,
      53,    72,    73,    76,    60,    27,    28,    29,    30,    38,
      76,    77,    78,    79,    80,    81,    38,    38,    57,    67,
      58,    47,    48,    49,    68,    70,    17,    36,    37,    38,
      55,    80,    83,    83,    38,    79,    55,    61,    26,    57,
      44,    55,    74,    74,    71,    61,    57,    83,    55,    83,
       5,    16,    31,    39,    40,    41,    34,    44,    33,    82,
      83,    83,    79,    83,    66,    75,    60,    57,    76,    36,
      83,    82,    56,    83,    83,    79,    83,    83,    83,    79,
      83,    83,    56,    59,    62,    60,    56,    57,    70,    45,
      45,    56,    32,    61,    69,    83,    68,    66,    57,    36,
      83,    79,    36,    83,    34,    60,    62,    62,    45,    45,
      79,    68,    50,    50,    36,    83,    47,    48,    47,    48,
      62,    62
};

#define yyerrok		(yyerrstatus = 0)
#define yyclearin	(yychar = YYEMPTY)
#define YYEMPTY		(-2)
#define YYEOF		0

#define YYACCEPT	goto yyacceptlab
#define YYABORT		goto yyabortlab
#define YYERROR		goto yyerrorlab


/* Like YYERROR except do call yyerror.  This remains here temporarily
   to ease the transition to the new meaning of YYERROR, for GCC.
   Once GCC version 2 has supplanted version 1, this can go.  */

#define YYFAIL		goto yyerrlab

#define YYRECOVERING()  (!!yyerrstatus)

#define YYBACKUP(Token, Value)					\
do								\
  if (yychar == YYEMPTY && yylen == 1)				\
    {								\
      yychar = (Token);						\
      yylval = (Value);						\
      yytoken = YYTRANSLATE (yychar);				\
      YYPOPSTACK (1);						\
      goto yybackup;						\
    }								\
  else								\
    {								\
      yyerror (YY_("syntax error: cannot back up")); \
      YYERROR;							\
    }								\
while (YYID (0))


#define YYTERROR	1
#define YYERRCODE	256


/* YYLLOC_DEFAULT -- Set CURRENT to span from RHS[1] to RHS[N].
   If N is 0, then set CURRENT to the empty location which ends
   the previous symbol: RHS[0] (always defined).  */

#define YYRHSLOC(Rhs, K) ((Rhs)[K])
#ifndef YYLLOC_DEFAULT
# define YYLLOC_DEFAULT(Current, Rhs, N)				\
    do									\
      if (YYID (N))                                                    \
	{								\
	  (Current).first_line   = YYRHSLOC (Rhs, 1).first_line;	\
	  (Current).first_column = YYRHSLOC (Rhs, 1).first_column;	\
	  (Current).last_line    = YYRHSLOC (Rhs, N).last_line;		\
	  (Current).last_column  = YYRHSLOC (Rhs, N).last_column;	\
	}								\
      else								\
	{								\
	  (Current).first_line   = (Current).last_line   =		\
	    YYRHSLOC (Rhs, 0).last_line;				\
	  (Current).first_column = (Current).last_column =		\
	    YYRHSLOC (Rhs, 0).last_column;				\
	}								\
    while (YYID (0))
#endif


/* YY_LOCATION_PRINT -- Print the location on the stream.
   This macro was not mandated originally: define only if we know
   we won't break user code: when these are the locations we know.  */

#ifndef YY_LOCATION_PRINT
# if defined YYLTYPE_IS_TRIVIAL && YYLTYPE_IS_TRIVIAL
#  define YY_LOCATION_PRINT(File, Loc)			\
     fprintf (File, "%d.%d-%d.%d",			\
	      (Loc).first_line, (Loc).first_column,	\
	      (Loc).last_line,  (Loc).last_column)
# else
#  define YY_LOCATION_PRINT(File, Loc) ((void) 0)
# endif
#endif


/* YYLEX -- calling `yylex' with the right arguments.  */

#ifdef YYLEX_PARAM
# define YYLEX yylex (YYLEX_PARAM)
#else
# define YYLEX yylex ()
#endif

/* Enable debugging if requested.  */
#if YYDEBUG

# ifndef YYFPRINTF
#  include <stdio.h> /* INFRINGES ON USER NAME SPACE */
#  define YYFPRINTF fprintf
# endif

# define YYDPRINTF(Args)			\
do {						\
  if (yydebug)					\
    YYFPRINTF Args;				\
} while (YYID (0))

# define YY_SYMBOL_PRINT(Title, Type, Value, Location)			  \
do {									  \
  if (yydebug)								  \
    {									  \
      YYFPRINTF (stderr, "%s ", Title);					  \
      yy_symbol_print (stderr,						  \
		  Type, Value); \
      YYFPRINTF (stderr, "\n");						  \
    }									  \
} while (YYID (0))


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_value_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_value_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (!yyvaluep)
    return;
# ifdef YYPRINT
  if (yytype < YYNTOKENS)
    YYPRINT (yyoutput, yytoknum[yytype], *yyvaluep);
# else
  YYUSE (yyoutput);
# endif
  switch (yytype)
    {
      default:
	break;
    }
}


/*--------------------------------.
| Print this symbol on YYOUTPUT.  |
`--------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_symbol_print (FILE *yyoutput, int yytype, YYSTYPE const * const yyvaluep)
#else
static void
yy_symbol_print (yyoutput, yytype, yyvaluep)
    FILE *yyoutput;
    int yytype;
    YYSTYPE const * const yyvaluep;
#endif
{
  if (yytype < YYNTOKENS)
    YYFPRINTF (yyoutput, "token %s (", yytname[yytype]);
  else
    YYFPRINTF (yyoutput, "nterm %s (", yytname[yytype]);

  yy_symbol_value_print (yyoutput, yytype, yyvaluep);
  YYFPRINTF (yyoutput, ")");
}

/*------------------------------------------------------------------.
| yy_stack_print -- Print the state stack from its BOTTOM up to its |
| TOP (included).                                                   |
`------------------------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_stack_print (yytype_int16 *bottom, yytype_int16 *top)
#else
static void
yy_stack_print (bottom, top)
    yytype_int16 *bottom;
    yytype_int16 *top;
#endif
{
  YYFPRINTF (stderr, "Stack now");
  for (; bottom <= top; ++bottom)
    YYFPRINTF (stderr, " %d", *bottom);
  YYFPRINTF (stderr, "\n");
}

# define YY_STACK_PRINT(Bottom, Top)				\
do {								\
  if (yydebug)							\
    yy_stack_print ((Bottom), (Top));				\
} while (YYID (0))


/*------------------------------------------------.
| Report that the YYRULE is going to be reduced.  |
`------------------------------------------------*/

#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yy_reduce_print (YYSTYPE *yyvsp, int yyrule)
#else
static void
yy_reduce_print (yyvsp, yyrule)
    YYSTYPE *yyvsp;
    int yyrule;
#endif
{
  int yynrhs = yyr2[yyrule];
  int yyi;
  unsigned long int yylno = yyrline[yyrule];
  YYFPRINTF (stderr, "Reducing stack by rule %d (line %lu):\n",
	     yyrule - 1, yylno);
  /* The symbols being reduced.  */
  for (yyi = 0; yyi < yynrhs; yyi++)
    {
      fprintf (stderr, "   $%d = ", yyi + 1);
      yy_symbol_print (stderr, yyrhs[yyprhs[yyrule] + yyi],
		       &(yyvsp[(yyi + 1) - (yynrhs)])
		       		       );
      fprintf (stderr, "\n");
    }
}

# define YY_REDUCE_PRINT(Rule)		\
do {					\
  if (yydebug)				\
    yy_reduce_print (yyvsp, Rule); \
} while (YYID (0))

/* Nonzero means print parse trace.  It is left uninitialized so that
   multiple parsers can coexist.  */
int yydebug;
#else /* !YYDEBUG */
# define YYDPRINTF(Args)
# define YY_SYMBOL_PRINT(Title, Type, Value, Location)
# define YY_STACK_PRINT(Bottom, Top)
# define YY_REDUCE_PRINT(Rule)
#endif /* !YYDEBUG */


/* YYINITDEPTH -- initial size of the parser's stacks.  */
#ifndef	YYINITDEPTH
# define YYINITDEPTH 200
#endif

/* YYMAXDEPTH -- maximum size the stacks can grow to (effective only
   if the built-in stack extension method is used).

   Do not make this value too large; the results are undefined if
   YYSTACK_ALLOC_MAXIMUM < YYSTACK_BYTES (YYMAXDEPTH)
   evaluated with infinite-precision integer arithmetic.  */

#ifndef YYMAXDEPTH
# define YYMAXDEPTH 10000
#endif



#if YYERROR_VERBOSE

# ifndef yystrlen
#  if defined __GLIBC__ && defined _STRING_H
#   define yystrlen strlen
#  else
/* Return the length of YYSTR.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static YYSIZE_T
yystrlen (const char *yystr)
#else
static YYSIZE_T
yystrlen (yystr)
    const char *yystr;
#endif
{
  YYSIZE_T yylen;
  for (yylen = 0; yystr[yylen]; yylen++)
    continue;
  return yylen;
}
#  endif
# endif

# ifndef yystpcpy
#  if defined __GLIBC__ && defined _STRING_H && defined _GNU_SOURCE
#   define yystpcpy stpcpy
#  else
/* Copy YYSRC to YYDEST, returning the address of the terminating '\0' in
   YYDEST.  */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static char *
yystpcpy (char *yydest, const char *yysrc)
#else
static char *
yystpcpy (yydest, yysrc)
    char *yydest;
    const char *yysrc;
#endif
{
  char *yyd = yydest;
  const char *yys = yysrc;

  while ((*yyd++ = *yys++) != '\0')
    continue;

  return yyd - 1;
}
#  endif
# endif

# ifndef yytnamerr
/* Copy to YYRES the contents of YYSTR after stripping away unnecessary
   quotes and backslashes, so that it's suitable for yyerror.  The
   heuristic is that double-quoting is unnecessary unless the string
   contains an apostrophe, a comma, or backslash (other than
   backslash-backslash).  YYSTR is taken from yytname.  If YYRES is
   null, do not copy; instead, return the length of what the result
   would have been.  */
static YYSIZE_T
yytnamerr (char *yyres, const char *yystr)
{
  if (*yystr == '"')
    {
      YYSIZE_T yyn = 0;
      char const *yyp = yystr;

      for (;;)
	switch (*++yyp)
	  {
	  case '\'':
	  case ',':
	    goto do_not_strip_quotes;

	  case '\\':
	    if (*++yyp != '\\')
	      goto do_not_strip_quotes;
	    /* Fall through.  */
	  default:
	    if (yyres)
	      yyres[yyn] = *yyp;
	    yyn++;
	    break;

	  case '"':
	    if (yyres)
	      yyres[yyn] = '\0';
	    return yyn;
	  }
    do_not_strip_quotes: ;
    }

  if (! yyres)
    return yystrlen (yystr);

  return yystpcpy (yyres, yystr) - yyres;
}
# endif

/* Copy into YYRESULT an error message about the unexpected token
   YYCHAR while in state YYSTATE.  Return the number of bytes copied,
   including the terminating null byte.  If YYRESULT is null, do not
   copy anything; just return the number of bytes that would be
   copied.  As a special case, return 0 if an ordinary "syntax error"
   message will do.  Return YYSIZE_MAXIMUM if overflow occurs during
   size calculation.  */
static YYSIZE_T
yysyntax_error (char *yyresult, int yystate, int yychar)
{
  int yyn = yypact[yystate];

  if (! (YYPACT_NINF < yyn && yyn <= YYLAST))
    return 0;
  else
    {
      int yytype = YYTRANSLATE (yychar);
      YYSIZE_T yysize0 = yytnamerr (0, yytname[yytype]);
      YYSIZE_T yysize = yysize0;
      YYSIZE_T yysize1;
      int yysize_overflow = 0;
      enum { YYERROR_VERBOSE_ARGS_MAXIMUM = 5 };
      char const *yyarg[YYERROR_VERBOSE_ARGS_MAXIMUM];
      int yyx;

# if 0
      /* This is so xgettext sees the translatable formats that are
	 constructed on the fly.  */
      YY_("syntax error, unexpected %s");
      YY_("syntax error, unexpected %s, expecting %s");
      YY_("syntax error, unexpected %s, expecting %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s");
      YY_("syntax error, unexpected %s, expecting %s or %s or %s or %s");
# endif
      char *yyfmt;
      char const *yyf;
      static char const yyunexpected[] = "syntax error, unexpected %s";
      static char const yyexpecting[] = ", expecting %s";
      static char const yyor[] = " or %s";
      char yyformat[sizeof yyunexpected
		    + sizeof yyexpecting - 1
		    + ((YYERROR_VERBOSE_ARGS_MAXIMUM - 2)
		       * (sizeof yyor - 1))];
      char const *yyprefix = yyexpecting;

      /* Start YYX at -YYN if negative to avoid negative indexes in
	 YYCHECK.  */
      int yyxbegin = yyn < 0 ? -yyn : 0;

      /* Stay within bounds of both yycheck and yytname.  */
      int yychecklim = YYLAST - yyn + 1;
      int yyxend = yychecklim < YYNTOKENS ? yychecklim : YYNTOKENS;
      int yycount = 1;

      yyarg[0] = yytname[yytype];
      yyfmt = yystpcpy (yyformat, yyunexpected);

      for (yyx = yyxbegin; yyx < yyxend; ++yyx)
	if (yycheck[yyx + yyn] == yyx && yyx != YYTERROR)
	  {
	    if (yycount == YYERROR_VERBOSE_ARGS_MAXIMUM)
	      {
		yycount = 1;
		yysize = yysize0;
		yyformat[sizeof yyunexpected - 1] = '\0';
		break;
	      }
	    yyarg[yycount++] = yytname[yyx];
	    yysize1 = yysize + yytnamerr (0, yytname[yyx]);
	    yysize_overflow |= (yysize1 < yysize);
	    yysize = yysize1;
	    yyfmt = yystpcpy (yyfmt, yyprefix);
	    yyprefix = yyor;
	  }

      yyf = YY_(yyformat);
      yysize1 = yysize + yystrlen (yyf);
      yysize_overflow |= (yysize1 < yysize);
      yysize = yysize1;

      if (yysize_overflow)
	return YYSIZE_MAXIMUM;

      if (yyresult)
	{
	  /* Avoid sprintf, as that infringes on the user's name space.
	     Don't have undefined behavior even if the translation
	     produced a string with the wrong number of "%s"s.  */
	  char *yyp = yyresult;
	  int yyi = 0;
	  while ((*yyp = *yyf) != '\0')
	    {
	      if (*yyp == '%' && yyf[1] == 's' && yyi < yycount)
		{
		  yyp += yytnamerr (yyp, yyarg[yyi++]);
		  yyf += 2;
		}
	      else
		{
		  yyp++;
		  yyf++;
		}
	    }
	}
      return yysize;
    }
}
#endif /* YYERROR_VERBOSE */


/*-----------------------------------------------.
| Release the memory associated to this symbol.  |
`-----------------------------------------------*/

/*ARGSUSED*/
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
static void
yydestruct (const char *yymsg, int yytype, YYSTYPE *yyvaluep)
#else
static void
yydestruct (yymsg, yytype, yyvaluep)
    const char *yymsg;
    int yytype;
    YYSTYPE *yyvaluep;
#endif
{
  YYUSE (yyvaluep);

  if (!yymsg)
    yymsg = "Deleting";
  YY_SYMBOL_PRINT (yymsg, yytype, yyvaluep, yylocationp);

  switch (yytype)
    {

      default:
	break;
    }
}


/* Prevent warnings from -Wmissing-prototypes.  */

#ifdef YYPARSE_PARAM
#if defined __STDC__ || defined __cplusplus
int yyparse (void *YYPARSE_PARAM);
#else
int yyparse ();
#endif
#else /* ! YYPARSE_PARAM */
#if defined __STDC__ || defined __cplusplus
int yyparse (void);
#else
int yyparse ();
#endif
#endif /* ! YYPARSE_PARAM */



/* The look-ahead symbol.  */
int yychar;

/* The semantic value of the look-ahead symbol.  */
YYSTYPE yylval;

/* Number of syntax errors so far.  */
int yynerrs;



/*----------.
| yyparse.  |
`----------*/

#ifdef YYPARSE_PARAM
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void *YYPARSE_PARAM)
#else
int
yyparse (YYPARSE_PARAM)
    void *YYPARSE_PARAM;
#endif
#else /* ! YYPARSE_PARAM */
#if (defined __STDC__ || defined __C99__FUNC__ \
     || defined __cplusplus || defined _MSC_VER)
int
yyparse (void)
#else
int
yyparse ()

#endif
#endif
{
  
  int yystate;
  int yyn;
  int yyresult;
  /* Number of tokens to shift before error messages enabled.  */
  int yyerrstatus;
  /* Look-ahead token as an internal (translated) token number.  */
  int yytoken = 0;
#if YYERROR_VERBOSE
  /* Buffer for error messages, and its allocated size.  */
  char yymsgbuf[128];
  char *yymsg = yymsgbuf;
  YYSIZE_T yymsg_alloc = sizeof yymsgbuf;
#endif

  /* Three stacks and their tools:
     `yyss': related to states,
     `yyvs': related to semantic values,
     `yyls': related to locations.

     Refer to the stacks thru separate pointers, to allow yyoverflow
     to reallocate them elsewhere.  */

  /* The state stack.  */
  yytype_int16 yyssa[YYINITDEPTH];
  yytype_int16 *yyss = yyssa;
  yytype_int16 *yyssp;

  /* The semantic value stack.  */
  YYSTYPE yyvsa[YYINITDEPTH];
  YYSTYPE *yyvs = yyvsa;
  YYSTYPE *yyvsp;



#define YYPOPSTACK(N)   (yyvsp -= (N), yyssp -= (N))

  YYSIZE_T yystacksize = YYINITDEPTH;

  /* The variables used to return semantic value and location from the
     action routines.  */
  YYSTYPE yyval;


  /* The number of symbols on the RHS of the reduced rule.
     Keep to zero when no symbol should be popped.  */
  int yylen = 0;

  YYDPRINTF ((stderr, "Starting parse\n"));

  yystate = 0;
  yyerrstatus = 0;
  yynerrs = 0;
  yychar = YYEMPTY;		/* Cause a token to be read.  */

  /* Initialize stack pointers.
     Waste one element of value and location stack
     so that they stay on the same level as the state stack.
     The wasted elements are never initialized.  */

  yyssp = yyss;
  yyvsp = yyvs;

  goto yysetstate;

/*------------------------------------------------------------.
| yynewstate -- Push a new state, which is found in yystate.  |
`------------------------------------------------------------*/
 yynewstate:
  /* In all cases, when you get here, the value and location stacks
     have just been pushed.  So pushing a state here evens the stacks.  */
  yyssp++;

 yysetstate:
  *yyssp = yystate;

  if (yyss + yystacksize - 1 <= yyssp)
    {
      /* Get the current used size of the three stacks, in elements.  */
      YYSIZE_T yysize = yyssp - yyss + 1;

#ifdef yyoverflow
      {
	/* Give user a chance to reallocate the stack.  Use copies of
	   these so that the &'s don't force the real ones into
	   memory.  */
	YYSTYPE *yyvs1 = yyvs;
	yytype_int16 *yyss1 = yyss;


	/* Each stack pointer address is followed by the size of the
	   data in use in that stack, in bytes.  This used to be a
	   conditional around just the two extra args, but that might
	   be undefined if yyoverflow is a macro.  */
	yyoverflow (YY_("memory exhausted"),
		    &yyss1, yysize * sizeof (*yyssp),
		    &yyvs1, yysize * sizeof (*yyvsp),

		    &yystacksize);

	yyss = yyss1;
	yyvs = yyvs1;
      }
#else /* no yyoverflow */
# ifndef YYSTACK_RELOCATE
      goto yyexhaustedlab;
# else
      /* Extend the stack our own way.  */
      if (YYMAXDEPTH <= yystacksize)
	goto yyexhaustedlab;
      yystacksize *= 2;
      if (YYMAXDEPTH < yystacksize)
	yystacksize = YYMAXDEPTH;

      {
	yytype_int16 *yyss1 = yyss;
	union yyalloc *yyptr =
	  (union yyalloc *) YYSTACK_ALLOC (YYSTACK_BYTES (yystacksize));
	if (! yyptr)
	  goto yyexhaustedlab;
	YYSTACK_RELOCATE (yyss);
	YYSTACK_RELOCATE (yyvs);

#  undef YYSTACK_RELOCATE
	if (yyss1 != yyssa)
	  YYSTACK_FREE (yyss1);
      }
# endif
#endif /* no yyoverflow */

      yyssp = yyss + yysize - 1;
      yyvsp = yyvs + yysize - 1;


      YYDPRINTF ((stderr, "Stack size increased to %lu\n",
		  (unsigned long int) yystacksize));

      if (yyss + yystacksize - 1 <= yyssp)
	YYABORT;
    }

  YYDPRINTF ((stderr, "Entering state %d\n", yystate));

  goto yybackup;

/*-----------.
| yybackup.  |
`-----------*/
yybackup:

  /* Do appropriate processing given the current state.  Read a
     look-ahead token if we need one and don't already have one.  */

  /* First try to decide what to do without reference to look-ahead token.  */
  yyn = yypact[yystate];
  if (yyn == YYPACT_NINF)
    goto yydefault;

  /* Not known => get a look-ahead token if don't already have one.  */

  /* YYCHAR is either YYEMPTY or YYEOF or a valid look-ahead symbol.  */
  if (yychar == YYEMPTY)
    {
      YYDPRINTF ((stderr, "Reading a token: "));
      yychar = YYLEX;
    }

  if (yychar <= YYEOF)
    {
      yychar = yytoken = YYEOF;
      YYDPRINTF ((stderr, "Now at end of input.\n"));
    }
  else
    {
      yytoken = YYTRANSLATE (yychar);
      YY_SYMBOL_PRINT ("Next token is", yytoken, &yylval, &yylloc);
    }

  /* If the proper action on seeing token YYTOKEN is to reduce or to
     detect an error, take that action.  */
  yyn += yytoken;
  if (yyn < 0 || YYLAST < yyn || yycheck[yyn] != yytoken)
    goto yydefault;
  yyn = yytable[yyn];
  if (yyn <= 0)
    {
      if (yyn == 0 || yyn == YYTABLE_NINF)
	goto yyerrlab;
      yyn = -yyn;
      goto yyreduce;
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  /* Count tokens shifted since error; after three, turn off error
     status.  */
  if (yyerrstatus)
    yyerrstatus--;

  /* Shift the look-ahead token.  */
  YY_SYMBOL_PRINT ("Shifting", yytoken, &yylval, &yylloc);

  /* Discard the shifted token unless it is eof.  */
  if (yychar != YYEOF)
    yychar = YYEMPTY;

  yystate = yyn;
  *++yyvsp = yylval;

  goto yynewstate;


/*-----------------------------------------------------------.
| yydefault -- do the default action for the current state.  |
`-----------------------------------------------------------*/
yydefault:
  yyn = yydefact[yystate];
  if (yyn == 0)
    goto yyerrlab;
  goto yyreduce;


/*-----------------------------.
| yyreduce -- Do a reduction.  |
`-----------------------------*/
yyreduce:
  /* yyn is the number of a rule to reduce with.  */
  yylen = yyr2[yyn];

  /* If YYLEN is nonzero, implement the default value of the action:
     `$$ = $1'.

     Otherwise, the following line sets YYVAL to garbage.
     This behavior is undocumented and Bison
     users should not rely upon it.  Assigning to YYVAL
     unconditionally makes the parser a bit smaller, and it avoids a
     GCC warning that YYVAL may be used uninitialized.  */
  yyval = yyvsp[1-yylen];


  YY_REDUCE_PRINT (yyn);
  switch (yyn)
    {
        case 2:
#line 111 "src/pc.y"
    { tree = (yyvsp[(1) - (1)].tval); tree_print(tree, 0);;}
    break;

  case 3:
#line 115 "src/pc.y"
    {(yyval.tval) = tree_make_program( (yyvsp[(2) - (10)].sval), (yyvsp[(4) - (10)].ltype_val), (yyvsp[(7) - (10)].tval), (yyvsp[(8) - (10)].tval), (yyvsp[(9) - (10)].tval));;}
    break;

  case 4:
#line 116 "src/pc.y"
    { yyerror("Syntax Error");;}
    break;

  case 5:
#line 121 "src/pc.y"
    { 
        // $$ = tree_make_id(hash_insert(symbol_tbl, $3), NULL, NULL);
        list_t *entry = list_make((yyvsp[(3) - (3)].sval));
        (yyval.ltype_val) = lname_make(entry);
        (yyval.ltype_val)->next = (yyvsp[(1) - (3)].ltype_val);
        ;}
    break;

  case 6:
#line 128 "src/pc.y"
    { 
        // hash_insert(symbol_tbl, $1); $$ = NULL;
        
        list_t *entry = list_make((yyvsp[(1) - (1)].sval));
        (yyval.ltype_val) = lname_make(entry);
    ;}
    break;

  case 7:
#line 138 "src/pc.y"
    {
        lname_t *names = (yyvsp[(3) - (6)].ltype_val);
        (yyval.tval) = tree_make_decl(names, (yyvsp[(5) - (6)].type_val));
        while (names) {
            list_t *entry = hash_insert(symbol_tbl, names->nptr);
            entry->type = (yyvsp[(5) - (6)].type_val);
            names = names->next;
        }
        if (names) {
            free(names);
        }
    ;}
    break;

  case 8:
#line 150 "src/pc.y"
    {(yyval.tval) = NULL; ;}
    break;

  case 9:
#line 154 "src/pc.y"
    { 
        (yyval.type_val) = tree_make_iarray((yyvsp[(3) - (8)].ival), tree_make_inum((yyvsp[(1) - (8)].sval), NULL, NULL), tree_make_inum((yyvsp[(5) - (8)].ival), NULL, NULL));
    ;}
    break;

  case 10:
#line 158 "src/pc.y"
    { 
        (yyval.type_val) = tree_make_rarray((yyvsp[(3) - (8)].ival), tree_make_inum((yyvsp[(1) - (8)].sval), NULL, NULL), tree_make_inum((yyvsp[(5) - (8)].ival), NULL, NULL));
    ;}
    break;

  case 11:
#line 162 "src/pc.y"
    { 
        (yyval.type_val) = tree_make_iarray((yyvsp[(3) - (8)].tval), (yyvsp[(5) - (8)].tval), (yyvsp[(7) - (8)].sval));
    ;}
    break;

  case 12:
#line 166 "src/pc.y"
    { 
        (yyval.type_val) = tree_make_rarray((yyvsp[(3) - (8)].tval), (yyvsp[(5) - (8)].tval), (yyvsp[(7) - (8)].sval));
    ;}
    break;

  case 13:
#line 169 "src/pc.y"
    { (yyval.type_val) = (yyvsp[(1) - (1)].type_val); ;}
    break;

  case 14:
#line 173 "src/pc.y"
    { 
        (yyval.tval) = tree_make_range((yyvsp[(2) - (5)].tval), (yyvsp[(4) - (5)].tval));
    ;}
    break;

  case 15:
#line 177 "src/pc.y"
    { 
        (yyval.tval) = tree_make_range((yyvsp[(2) - (5)].ival), (yyvsp[(4) - (5)].ival));
    ;}
    break;

  case 16:
#line 182 "src/pc.y"
    { 
        ptype_t *t = malloc(sizeof(ptype_t));
        t->type = INTEGER;
        t->size = sizeof(int);
        t->subtype = NULL;
        (yyval.type_val) = t;
    ;}
    break;

  case 17:
#line 189 "src/pc.y"
    {
        ptype_t *t = malloc(sizeof(ptype_t));
        t->type = REAL;
        t->size = sizeof(double);
        t->subtype = NULL;
        (yyval.type_val) = t;
    ;}
    break;

  case 18:
#line 199 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 19:
#line 200 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 20:
#line 204 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 21:
#line 208 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 22:
#line 209 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 23:
#line 213 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 24:
#line 214 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 25:
#line 218 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 26:
#line 219 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 27:
#line 223 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 28:
#line 227 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 29:
#line 228 "src/pc.y"
    {(yyval.tval) = NULL; ;}
    break;

  case 30:
#line 232 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 31:
#line 233 "src/pc.y"
    {(yyval.tval) = (yyvsp[(1) - (1)].tval);;}
    break;

  case 32:
#line 237 "src/pc.y"
    {(yyval.tval) = tree_make_assignop((yyvsp[(1) - (3)].tval), (yyvsp[(3) - (3)].tval));;}
    break;

  case 33:
#line 238 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 34:
#line 239 "src/pc.y"
    {(yyval.tval) = (yyvsp[(1) - (1)].tval);;}
    break;

  case 35:
#line 240 "src/pc.y"
    { (yyval.tval) = tree_make_if((yyvsp[(2) - (6)].tval), (yyvsp[(4) - (6)].tval), (yyvsp[(6) - (6)].tval));;}
    break;

  case 36:
#line 241 "src/pc.y"
    { (yyval.tval) = tree_make_if((yyvsp[(2) - (4)].tval), (yyvsp[(4) - (4)].tval), NULL);;}
    break;

  case 37:
#line 242 "src/pc.y"
    { (yyval.tval) = tree_make_while((yyvsp[(2) - (4)].tval), (yyvsp[(4) - (4)].tval));;}
    break;

  case 38:
#line 243 "src/pc.y"
    { (yyval.tval) = tree_make_repeat((yyvsp[(2) - (4)].tval), (yyvsp[(4) - (4)].tval));;}
    break;

  case 39:
#line 244 "src/pc.y"
    { (yyval.tval) = NULL:;}
    break;

  case 40:
#line 249 "src/pc.y"
    { (yyval.tval) = NULL;;}
    break;

  case 41:
#line 250 "src/pc.y"
    {(yyval.tval) = tree_make_id(hash_search_all(symbol_tbl, (yyvsp[(1) - (1)].sval)), NULL, NULL);;}
    break;

  case 42:
#line 254 "src/pc.y"
    { (yyval.tval) = NULL; ;}
    break;

  case 43:
#line 255 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 44:
#line 259 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 45:
#line 260 "src/pc.y"
    {(yyval.tval) = NULL;;}
    break;

  case 46:
#line 263 "src/pc.y"
    { (yyval.tval) = tree_make_addop(OR, (yyvsp[(1) - (3)].tval), (yyvsp[(3) - (3)].tval)); ;}
    break;

  case 47:
#line 264 "src/pc.y"
    { (yyval.tval) = tree_make_addop(AND, (yyvsp[(1) - (3)].tval), (yyvsp[(3) - (3)].tval)); ;}
    break;

  case 48:
#line 265 "src/pc.y"
    { (yyval.tval) = tree_make(NOT, (yyvsp[(2) - (2)].tval), NULL); ;}
    break;

  case 49:
#line 266 "src/pc.y"
    { (yyval.tval) = tree_make_relop((yyvsp[(2) - (3)].opval), (yyvsp[(1) - (3)].tval), (yyvsp[(3) - (3)].tval)); ;}
    break;

  case 50:
#line 267 "src/pc.y"
    { (yyval.tval) = tree_make_addop((yyvsp[(2) - (3)].opval), (yyvsp[(1) - (3)].tval), (yyvsp[(3) - (3)].tval)); ;}
    break;

  case 51:
#line 268 "src/pc.y"
    { (yyval.tval) = tree_make_mulop((yyvsp[(2) - (3)].opval), (yyvsp[(1) - (3)].tval), (yyvsp[(3) - (3)].tval)); ;}
    break;

  case 52:
#line 269 "src/pc.y"
    { (yyval.tval) = (yyvsp[(2) - (3)].tval); ;}
    break;

  case 53:
#line 270 "src/pc.y"
    { (yyval.tval) = tree_make_inum((yyvsp[(1) - (1)].ival), NULL, NULL); ;}
    break;

  case 54:
#line 271 "src/pc.y"
    { (yyval.tval) = tree_make_rnum((yyvsp[(1) - (1)].rval), NULL, NULL); ;}
    break;

  case 55:
#line 272 "src/pc.y"
    { (yyval.tval) = (yyvsp[(1) - (1)].tval); ;}
    break;

  case 56:
#line 273 "src/pc.y"
    { (yyval.tval) = NULL; ;}
    break;


/* Line 1267 of yacc.c.  */
#line 1901 "pc.tab.c"
      default: break;
    }
  YY_SYMBOL_PRINT ("-> $$ =", yyr1[yyn], &yyval, &yyloc);

  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);

  *++yyvsp = yyval;


  /* Now `shift' the result of the reduction.  Determine what state
     that goes to, based on the state we popped back to and the rule
     number reduced by.  */

  yyn = yyr1[yyn];

  yystate = yypgoto[yyn - YYNTOKENS] + *yyssp;
  if (0 <= yystate && yystate <= YYLAST && yycheck[yystate] == *yyssp)
    yystate = yytable[yystate];
  else
    yystate = yydefgoto[yyn - YYNTOKENS];

  goto yynewstate;


/*------------------------------------.
| yyerrlab -- here on detecting error |
`------------------------------------*/
yyerrlab:
  /* If not already recovering from an error, report this error.  */
  if (!yyerrstatus)
    {
      ++yynerrs;
#if ! YYERROR_VERBOSE
      yyerror (YY_("syntax error"));
#else
      {
	YYSIZE_T yysize = yysyntax_error (0, yystate, yychar);
	if (yymsg_alloc < yysize && yymsg_alloc < YYSTACK_ALLOC_MAXIMUM)
	  {
	    YYSIZE_T yyalloc = 2 * yysize;
	    if (! (yysize <= yyalloc && yyalloc <= YYSTACK_ALLOC_MAXIMUM))
	      yyalloc = YYSTACK_ALLOC_MAXIMUM;
	    if (yymsg != yymsgbuf)
	      YYSTACK_FREE (yymsg);
	    yymsg = (char *) YYSTACK_ALLOC (yyalloc);
	    if (yymsg)
	      yymsg_alloc = yyalloc;
	    else
	      {
		yymsg = yymsgbuf;
		yymsg_alloc = sizeof yymsgbuf;
	      }
	  }

	if (0 < yysize && yysize <= yymsg_alloc)
	  {
	    (void) yysyntax_error (yymsg, yystate, yychar);
	    yyerror (yymsg);
	  }
	else
	  {
	    yyerror (YY_("syntax error"));
	    if (yysize != 0)
	      goto yyexhaustedlab;
	  }
      }
#endif
    }



  if (yyerrstatus == 3)
    {
      /* If just tried and failed to reuse look-ahead token after an
	 error, discard it.  */

      if (yychar <= YYEOF)
	{
	  /* Return failure if at end of input.  */
	  if (yychar == YYEOF)
	    YYABORT;
	}
      else
	{
	  yydestruct ("Error: discarding",
		      yytoken, &yylval);
	  yychar = YYEMPTY;
	}
    }

  /* Else will try to reuse look-ahead token after shifting the error
     token.  */
  goto yyerrlab1;


/*---------------------------------------------------.
| yyerrorlab -- error raised explicitly by YYERROR.  |
`---------------------------------------------------*/
yyerrorlab:

  /* Pacify compilers like GCC when the user code never invokes
     YYERROR and the label yyerrorlab therefore never appears in user
     code.  */
  if (/*CONSTCOND*/ 0)
     goto yyerrorlab;

  /* Do not reclaim the symbols of the rule which action triggered
     this YYERROR.  */
  YYPOPSTACK (yylen);
  yylen = 0;
  YY_STACK_PRINT (yyss, yyssp);
  yystate = *yyssp;
  goto yyerrlab1;


/*-------------------------------------------------------------.
| yyerrlab1 -- common code for both syntax error and YYERROR.  |
`-------------------------------------------------------------*/
yyerrlab1:
  yyerrstatus = 3;	/* Each real token shifted decrements this.  */

  for (;;)
    {
      yyn = yypact[yystate];
      if (yyn != YYPACT_NINF)
	{
	  yyn += YYTERROR;
	  if (0 <= yyn && yyn <= YYLAST && yycheck[yyn] == YYTERROR)
	    {
	      yyn = yytable[yyn];
	      if (0 < yyn)
		break;
	    }
	}

      /* Pop the current state because it cannot handle the error token.  */
      if (yyssp == yyss)
	YYABORT;


      yydestruct ("Error: popping",
		  yystos[yystate], yyvsp);
      YYPOPSTACK (1);
      yystate = *yyssp;
      YY_STACK_PRINT (yyss, yyssp);
    }

  if (yyn == YYFINAL)
    YYACCEPT;

  *++yyvsp = yylval;


  /* Shift the error token.  */
  YY_SYMBOL_PRINT ("Shifting", yystos[yyn], yyvsp, yylsp);

  yystate = yyn;
  goto yynewstate;


/*-------------------------------------.
| yyacceptlab -- YYACCEPT comes here.  |
`-------------------------------------*/
yyacceptlab:
  yyresult = 0;
  goto yyreturn;

/*-----------------------------------.
| yyabortlab -- YYABORT comes here.  |
`-----------------------------------*/
yyabortlab:
  yyresult = 1;
  goto yyreturn;

#ifndef yyoverflow
/*-------------------------------------------------.
| yyexhaustedlab -- memory exhaustion comes here.  |
`-------------------------------------------------*/
yyexhaustedlab:
  yyerror (YY_("memory exhausted"));
  yyresult = 2;
  /* Fall through.  */
#endif

yyreturn:
  if (yychar != YYEOF && yychar != YYEMPTY)
     yydestruct ("Cleanup: discarding lookahead",
		 yytoken, &yylval);
  /* Do not reclaim the symbols of the rule which action triggered
     this YYABORT or YYACCEPT.  */
  YYPOPSTACK (yylen);
  YY_STACK_PRINT (yyss, yyssp);
  while (yyssp != yyss)
    {
      yydestruct ("Cleanup: popping",
		  yystos[*yyssp], yyvsp);
      YYPOPSTACK (1);
    }
#ifndef yyoverflow
  if (yyss != yyssa)
    YYSTACK_FREE (yyss);
#endif
#if YYERROR_VERBOSE
  if (yymsg != yymsgbuf)
    YYSTACK_FREE (yymsg);
#endif
  /* Make sure YYID is used.  */
  return YYID (yyresult);
}


#line 321 "src/pc.y"


int main(int argc, char *argv[]) {
    symbol_tbl = hash_make();
    tree = NULL;

    if (argc > 1) {
        yyfilename = argv[1];  // Set filename from command-line argument
        char *valid_extensions[] = {".pas", ".p", ".pp", ".inc", ".pascal"};
        int valid = 0;

        for (int i = 0; i < 5; i++) {
            if (strstr(yyfilename, valid_extensions[i]) != NULL) {
                yyin = fopen(yyfilename, "r");
                valid = 1;
                break;
            }
        }

        if (!valid) {
            fprintf(stderr, "Invalid file extension: %s\n", yyfilename);
            return 1;
        }

        if (!yyin) {
            fprintf(stderr,"Error opening file\n");
            return 1;
        }
    } 
    else {
        yyfilename = "input"; 
        yyin = stdin;  
    }

    if (yyparse() == 0) {
        printf("\nParsing Finished.\n");
        if (are_there_messages(&error_warning)) {
            print_all_messages(&error_warning);
            /* fprintf(stderr, "Parsing Completed with %d errors.\n", error_count); */
        }
    } 
    else {
        fprintf(stderr, "Parsing Failed.\n");
    }
    
    return 0;
}

