/* A Bison parser, made by GNU Bison 3.5.1.  */

/* Bison interface for Yacc-like parsers in C

   Copyright (C) 1984, 1989-1990, 2000-2015, 2018-2020 Free Software Foundation,
   Inc.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 3 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>.  */

/* As a special exception, you may create a larger work that contains
   part or all of the Bison parser skeleton and distribute that work
   under terms of your choice, so long as that work isn't itself a
   parser generator using the skeleton or a modified version thereof
   as a parser skeleton.  Alternatively, if you modify or redistribute
   the parser skeleton itself, you may (at your option) remove this
   special exception, which will cause the skeleton and the resulting
   Bison output files to be licensed under the GNU General Public
   License without this special exception.

   This special exception was added by the Free Software Foundation in
   version 2.2 of Bison.  */

/* Undocumented macros, especially those whose name start with YY_,
   are private implementation details.  Do not rely on them.  */

#ifndef YY_YY_SRC_PC_TAB_H_INCLUDED
# define YY_YY_SRC_PC_TAB_H_INCLUDED
/* Debug traces.  */
#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int yydebug;
#endif

/* Token type.  */
#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    PLUS = 258,
    MINUS = 259,
    OR = 260,
    EQ = 261,
    NE = 262,
    LT = 263,
    GT = 264,
    LE = 265,
    GE = 266,
    STAR = 267,
    SLASH = 268,
    DIV = 269,
    MOD = 270,
    AND = 271,
    NOT = 272,
    COMMA = 273,
    P = 274,
    B = 275,
    SEMICOLON = 276,
    COLON = 277,
    RARRAY = 278,
    IARRAY = 279,
    FUNC_CALL = 280,
    STMT_LIST = 281,
    CMPND_STMT = 282,
    DECLS = 283,
    SUBPROG_DECLS = 284,
    PARAM_LIST = 285,
    RANGE = 286,
    EXPR_LIST = 287,
    PROC_CALL = 288,
    ARRAY_CALL = 289,
    SUBPROG_DECL = 290,
    FOR_ARG = 291,
    ID_LIST = 292,
    PARAMETER = 293,
    LOCAL = 294,
    VOID = 295,
    BEGINKW = 296,
    END = 297,
    IF = 298,
    WHILE = 299,
    FOR = 300,
    REPEAT = 301,
    THEN = 302,
    ELSE = 303,
    UNTIL = 304,
    DO = 305,
    DECL = 306,
    INUM = 307,
    RNUM = 308,
    ID = 309,
    RELOP = 310,
    ADDOP = 311,
    MULOP = 312,
    ANDOP = 313,
    OROP = 314,
    ASSIGNOP = 315,
    DOUBLEDOT = 316,
    VAR = 317,
    INTEGER = 318,
    REAL = 319,
    BOOL = 320,
    ARRAY = 321,
    OF = 322,
    PROGRAM = 323,
    FUNCTION = 324,
    PROCEDURE = 325,
    SUBPROGRAM = 326,
    PROG_DECL1 = 327,
    PROG_DECL2 = 328,
    ELSEFIX = 329,
    UMINUS = 330
  };
#endif

/* Value type.  */
#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 29 "src/pc.y"

    int ival;
    float rval;
    int opval;
    char *sval;
    tree_t *tval;       /* tree value */

#line 141 "src/pc.tab.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif


extern YYSTYPE yylval;

int yyparse (void);

#endif /* !YY_YY_SRC_PC_TAB_H_INCLUDED  */
