#ifndef TOKENS_H
#define TOKENS_H


#define PLUS 258
#define MINUS 259
#define OR 260
#define EQ 261
#define NE 262
#define LT 263
#define GT 264
#define LE 265
#define GE 266
#define STAR 267
#define SLASH 268
#define DIV 269
#define MOD 270
#define AND 271
#define COMMA 272
#define P 273
#define B 274
#define SEMICOLON 275
#define COLON 276
#define BEGINKW 277
#define END 278
#define IF 279
#define WHILE 280
#define FOR 281
#define REPEAT 282
#define THEN 283
#define ELSE 284
#define UNTIL 285
#define DO 286
#define INUM 287
#define RNUM 288
#define ID 289
#define RELOP 290
#define ADDOP 291
#define MULOP 292
#define ASSIGNOP 293
#define DOUBLEDOT 294
#define VAR 295
#define INTEGER 296
#define REAL 297
#define ARRAY 298
#define OF 299
#define PROGRAM 300
#define FUNCTION 301
#define PROCEDURE 302
#define NOT 303

#endif // TOKENS_H