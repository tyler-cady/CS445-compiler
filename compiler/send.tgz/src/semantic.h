#ifndef SEMANTIC_H
#define SEMANTIC_H



#include "tree.h"
#include "hash.h"
#include "error.h"
#include "tokens.h"
#include "util.h"

/* Semantic checks */

#endif // SEMANTIC_H